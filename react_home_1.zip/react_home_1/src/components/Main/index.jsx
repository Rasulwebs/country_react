import "./stylemain.css";
import manimg from "../../assets/images/mann.jpg";
import girlimg from "../../assets/images/girll.jpg";
import elips1img from "../../assets/images/elips1.png";
import manssimg from "../../assets/images/manss.jpg";
import mankkimg from "../../assets/images/mankk.jpg";
import listnimg from "../../assets/images/listn.jpg";
import listtttimg from "../../assets/images/listttt.svg";
import boysimg from "../../assets/images/boys.jpg";
import kutubxonaimg from "../../assets/images/kutubxona.jpg";
import shirinimg from "../../assets/images/shirin.jpg";
import whearimg from "../../assets/images/whear.svg";
import logoWhatsAppimg from "../../assets/images/logos_whatsapp.svg";


const Main = () => {
  return (
    <>
      <main class="main">
        <div class="container one-cont">
          <section class="one">
            <div class="one__harus">
              <div class="one__harus__title">
                <h2>
                  Kenapa Kita <span>Harus</span>Membaca Buku?
                </h2>
              </div>

              <div class="one__harus__comments">
                <div class="one__harus__comments__card">
                  <p>
                    “Aku rela dipenjara asalkan <b>bersama buku,</b>karena
                    dengan buku <b>aku bebas”</b>
                  </p>
                  <br />

                  <div class="one__harus__comments__card__inf">
                    <img src={manimg} alt="man" className="cardimg"/>
                    <div class="one__harus__comments__card__inf__text">
                      <p class="one__harus__card__inf__tt">
                        <b>Mohammad Hatta</b>{" "}
                      </p>

                      <p class="one__harus__card__inf__text__pp">
                        Wakil Presiden Indonesia Pertama
                      </p>
                    </div>
                  </div>
                </div>

                <div class="one__harus__comments__card">
                  <p>
                    “Cuma perlu <b>satu buku</b>untuk jatuh cinta pada membaca,
                    Cari Buku itu! <b> Mari jatuh cinta!</b>
                  </p>
                  <br />

                  <div class="one__harus__comments__card__inf">
                    <img src={girlimg} alt="man" className="cardimg"/>
                    <div class="one__harus__comments__card__inf__text">
                      <p class="one__harus__card__inf__tt">
                        <b>Najwa Shihab</b>{" "}
                      </p>

                      <p class="one__harus__card__inf__text__pp">
                        Duta Membaca
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="one__stat">
              <div class="one__stat__card">
                <img src={elips1img} alt="elips" className="elips"/>

                <div class="one__stat__card__text">
                  <h2>500+</h2>

                  <p>Judul Buku</p>
                </div>
              </div>

              <div class="one__stat__card">
                <img src={elips1img} alt="elips" className="elips"/>

                <div class="one__stat__card__text">
                  <h2>$0</h2>

                  <p>Gratis Peminjaman</p>
                </div>
              </div>

              <div class="one__stat__card">
                <img src={elips1img} alt="elips" className="elips"/>

                <div class="one__stat__card__text">
                  <h2>5</h2>

                  <p>Kegiatan Rutin</p>
                </div>
              </div>
            </div>
          </section>

          <section class="two">
            <div class="two__title">
              <div class="two__title__lg">
                <h2>Apa Kata Mereka?</h2>
                <br />
                <p>Mereka yang telah menjadi pengunjung tetap kami</p>
              </div>

              <div class="two__title__rg">
                <p>Selengkapnya</p>
              </div>
            </div>

            <div class="two__cards">
              <div class="one__harus__comments__card">
                <p>
                  Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                  amet sint. Velit officia consequat duis enim velit mollit.
                  Exercitation veniam consequat sunt nostrud amet.
                </p>
                <br />

                <div class="one__harus__comments__card__inf">
                  <img src={manssimg} alt="man" className="man2"/>
                  <div class="one__harus__comments__card__inf__text">
                    <p class="one__harus__card__inf__tt">
                      <b>Guy Hawkins</b>{" "}
                    </p>

                    <p class="one__harus__card__inf__text__pp">
                      32 Tahun, Karyawan
                    </p>
                  </div>
                </div>
              </div>

              <div class="one__harus__comments__card">
                <p>
                  Amet minim mollit non deserunt ullamco est sit aliqua dolor do
                  amet sint. Velit officia consequat duis enim velit mollit.
                  Exercitation veniam consequat sunt nostrud amet.
                </p>
                <br />

                <div class="one__harus__comments__card__inf">
                  <img src={mankkimg} alt="man" className="man2"/>
                  <div class="one__harus__comments__card__inf__text">
                    <p class="one__harus__card__inf__tt">
                      <b>Brooklyn Simmons</b>{" "}
                    </p>

                    <p class="one__harus__card__inf__text__pp">
                      20 Tahun, Mahasiswa
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div class="two__lists">
              <img src={listnimg} alt="list" />
              <img src={listtttimg} alt="listt" />
              <img src={listtttimg} alt="listt" />
            </div>
          </section>

          <section class="three">
            <div class="two__title">
              <div class="two__title__lg">
                <h2>Kegiatan Pojok Baca Probolinggo</h2>
                <br />
                <p>Intip kegiatan yang telah kami selenggarakan </p>
              </div>

              <div class="two__title__rg">
                <p>Selengkapnya</p>
              </div>
            </div>

            <div class="three__imgcards">
              <div class="three__imgcards__cardd">
                <img src={boysimg} alt="bous" />
              </div>

              <div class="three__imgcards__cardt">
                <img src={kutubxonaimg} alt="kutubxona" />
              </div>

              <div class="three__imgcards__cardk">
                <img src={shirinimg} alt="shirin" />
              </div>
            </div>
          </section>

          <section class="four">
            <div class="four__contact">
              <h2>
                Ingin <span>Membantu</span>Meningkatkan Literasi Anak-Anak
                Sekitar Kita?
              </h2>

              <p>Percayakan melalui kegiatan kita</p>

              <button class="hero__gr-btns">
                Donasi dengan Kami <img src={whearimg} alt="soon" />
              </button>

              <p>Atau</p>

              <button class="hero__w-btnn">
                Hubungi Kami{" "}
                <img src={logoWhatsAppimg} alt="whatapp" />
              </button>
            </div>
          </section>
        </div>
      </main>
    </>
  );
};
export default Main;
