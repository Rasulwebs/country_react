import "./stylenavbar.css"
import logoimg from "../../assets/images/logobook.svg";
import searchimg from "../../assets/images/searchbtn.svg";
import soonimg from "../../assets/images/soonbtn.svg";
import heartimg from "../../assets/images/heartbook.png";
import reedbookimg from "../../assets/images/redbook.png";
import natureimg from "../../assets/images/naturebook.png";
import herolineimg from "../../assets/images/heroline.png";
import babyimg from "../../assets/images/babybook.png";
import rheartimg from "../../assets/images/rheartbook.png";
import babyrightimg from "../../assets/images/babyrightbook.png";
import runrightimg from "../../assets/images/runrightbook.png";

const Navbar=()=>{
    return(
        <>

<header>
        <div className="container header-cont">
            <nav className="nav">
                <span>
                    <a href="#"><img src={logoimg} alt="logo" /></a>
                </span>

                <div className="nav__links">
                    <a href="#" className="header__link">Beranda</a>
                    <a href="#" className="header__link">Koleksi</a>
                    <a href="#" className="header__link">Syarat dan Ketentuan</a>
                    <a href="#" className="header__link">Kontak</a>

                    <span className="nav__mask-link">
                        <a href="#" classNameName="header__link">Masuk</a>
                    </span>
                </div>
            </nav>
        </div>
    </header>

    <div className="hero">
        <div className="container hero__cont">

            <div className="hero__text">
                <span className="hero__pojo">
                    <p>Pojok Baca</p>
                </span>
                <p className="hero__textt"> Probolinggo</p>
            </div>

            <br/>
            <div className="hero__title">
                <h1>Pinjam Buku Secara <span className="hero__t-g">Gratis</span>untuk Masyarakat</h1>
            </div>

            <div className="hero__btn">
                <button className="hero__gr-btn">Cari Judul Buku <img src={searchimg} alt="sarch"/></button>

                <button className="hero__w-btn">Donasi dengan Kami <img src={soonimg} alt="soon"/></button>
            </div>


            <div className="hero__images">
                <div className="hero__images__left-img">
                    <img src={heartimg}alt="heart"/>

                    <br/><br/><br/><br/>
                    <span><img src={reedbookimg} alt="r-book"/></span>

                </div>

                <div className="hero__images__l-img">
                    <img src={natureimg} alt="nature"/>
                </div>

                <div className="hero__images__center">
                    <span><img src={herolineimg} alt="line"/></span>

                    <br/>
                    <img src={babyimg} alt="baby"/>
                </div>

                <div className="hero__images__r-img">
                    <img src={rheartimg} alt="bigheart"/>
                </div>

                <div className="hero__images__right-img">
                    <span>
                        <img src={babyrightimg} alt="right1"/>
                    </span>


                    <br/><br/><br/><br/><br/>

                    <img src={runrightimg} alt="run"/>
                </div>
            </div>
        </div>
    </div>


        </>
    )
}
export default Navbar