import "./stylefooter.css"
import logobook from "../../assets/images/logobook.svg";
import instagramimg from "../../assets/images/instagram.svg";
import facebookimg from "../../assets/images/facebook-fill.svg";
import youtubeimg from "../../assets/images/youtube-fill.svg";
import cimg from "../../assets/images/cccc.svg";

const Footer=()=>{

    return(
        <>
<footer class="foot">
        <div class="cont  foot__cont">
             <div class="cont__rll">
                <div class="cont__rll__logo">
                    <a href="./index.html">
                        <img src={logobook} alt="foot logo"/>
                    </a>
                    

                    <p>Pojok Baca Probolinggoo</p>
                </div>

                <div class="cont__rll__mss">
                    <img src={instagramimg} alt="instagram"/>
                    <img src={facebookimg} alt=" facebook"/>
                    <img src={youtubeimg} alt="youtube"/>
                </div>
             </div>

             <div class="cont__lul">
                <ul class="cont__lul__linkss">
                    <li class="cont__lul__linkss__lis-t li-title">Kontak<a href="#"></a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Email</a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Alamat</a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">No. Rekening</a></li>
                    
                </ul>

                <ul class="cont__lul__linkss">
                    <li class="cont__lul__linkss__lis-t li-title">Tentang Kami<a href="#"></a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Umum</a></li>
                    
                </ul>

                <ul class="cont__lul__linkss">
                    <li class="cont__lul__linkss__lis-t li-title">Galery<a href=""></a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Kegiatan</a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Kegiatan 2018</a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Kegiatan 2019</a></li>
                    <li class="cont__lul__linkss__lis"><a href="#">Kegiatan 2020</a></li>
                </ul>
             </div>
       

            
                
             </div>

             <div class="cont__end">
                <div class="cont__end__text">
                    <img src={cimg} alt="c" width="24"/>
                    <p>Pojok Baca Probolinggo 2022</p>
                </div>
        </div>
    </footer>
        </>
    )
}
export default Footer